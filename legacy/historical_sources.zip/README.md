# Historical sources

This archive contains the original GPT-5.5 follow-up ZIP and metadata for the public paper-code repository as frozen before the 2026 correction.

The complete paper-era source code remains in the Git history of the same repository at commit:

`81206df955622c31225f0d4f9c290e35d41ba381`

Before uploading the corrected root, create a branch named `paper-2024-original` from the current `main` branch. That branch is the authoritative executable snapshot of the historical root scripts.
