# Frozen legacy GitHub repository reference

This directory records the historical public repository before any upgrade.

- Repository: `GoGoKo699/Random-Density-Matrix`
- Default branch: `main`
- Frozen commit: `81206df955622c31225f0d4f9c290e35d41ba381`
- Frozen tree: `726268085341dbaff3183591e9b5ee036a9e3bf9`
- Commit date: 16 January 2024
- Files in tree: 17

The authoritative path/blob/size manifest is `../../metadata/repository_tree_manifest.csv`, and full snapshot metadata are in `../../metadata/repository_snapshot.json`.

## Important limitation

The execution container had no direct Git network transport, so this checkpoint does **not** pretend to contain a local byte-for-byte checkout. The freeze is instead anchored to immutable Git commit, tree, and blob identifiers obtained through the connected GitHub API. Those identifiers are sufficient to identify the exact historical public tree. The final GitHub package will preserve the legacy layer explicitly rather than silently rewriting history.
