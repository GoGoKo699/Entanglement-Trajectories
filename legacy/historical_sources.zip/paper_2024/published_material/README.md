# Frozen published record

The version of record is:

**Ruge Lin, “Entanglement Trajectory and its Boundary,” Quantum 8, 1282 (2024).**  
DOI: `10.22331/q-2024-03-14-1282`  
Published: 14 March 2024  
License: CC BY 4.0

The associated versioned preprint is `arXiv:2303.13587v5`, last revised 8 March 2024.

Full machine-readable metadata are in `../../metadata/published_paper_snapshot.json`. The first-pass correction ledger is in `../../metadata/paper_claim_seed.csv` and the complete project claim registry is in `../../metadata/claims.json`.

## Important limitation

This checkpoint freezes the publication by DOI and the source by explicit arXiv version. The execution container could not fetch a local PDF/source byte mirror. No claim is made that publication bytes are stored here. A later byte mirror can be added without changing which version is authoritative.
