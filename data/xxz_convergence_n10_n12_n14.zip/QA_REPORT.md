# PR-001 Checkpoint QA

## Status

**PASS**

## Verified contents

- 3,528 convergence observations.
- 72 complete trajectories.
- Sizes `10,12,14`.
- Run IDs `XXZ_1` through `XXZ_4`.
- Substep counts `1,2,4,8,16,32`.
- No duplicate `(n, run_id, substeps, step)` records.
- Every trajectory contains exactly `4n+1` observations.
- All three figures open successfully and were inspected together in `figures/PR001_contact_sheet.png`.
- The reproducibility script passes a small smoke run.
- The numerical verification script reports:

```text
PR-001 checkpoint verification: PASS
```

## Frozen numerical checks

- Worst `8 -> 16` maximum discrepancy: `0.0065659184793661`.
- Worst `16 -> 32` maximum discrepancy: `0.0016619712941260`.
- Worst `16 -> 32` RMS discrepancy: `0.0010568300183579`.
- Median final refinement order is between `1.99` and `2.02` for every metric.
- Global common-mode shift between one and 32 substeps is below `0.001`.

## Scope limitation

The convergence computation covers `n=10,12,14`. It does not certify refined Hamiltonian trajectories at `n=16,18,20`. The checkpoint therefore recommends retaining the existing full-size dataset only under the explicit fixed product-formula circuit interpretation.
