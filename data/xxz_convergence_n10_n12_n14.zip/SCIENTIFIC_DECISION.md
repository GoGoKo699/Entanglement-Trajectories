# Scientific Decision after PR-001

## Decision

The current one-substep XXZ trajectories will **not** be promoted as converged random-field XXZ Hamiltonian dynamics.

They may be retained as trajectories of a fully specified discrete circuit:

> fixed one-substep symmetric product-formula circuits generated from random-field XXZ terms.

This is the narrowest correction that preserves the existing 5,856-row dataset and the project’s actual central result.

## Why this is the preferred route

The convergence study establishes three separate facts:

1. **The physical approximation is not converged at one substep.** Individual XXZ trajectories can move substantially under refinement.
2. **The product formula enters its expected second-order regime.** Sixteen versus 32 substeps changes all tested normalized coordinates by at most 0.001662 for \(n=10,12,14\).
3. **The project’s main multi-metric conclusion is stable.** The global common-mode fraction changes by less than 0.0006 between the one-substep and 32-substep replacements over the audited sizes.

The central claim is about relationships among projections of a Schmidt-spectrum path. It does not require the fourth dynamical family to approximate a continuum Hamiltonian with a specified error.

## Public wording to freeze

Use:

> four dynamical families used to probe scrambling, recurrence, disorder, and spectral complexity.

For the fourth family, use:

> random-field XXZ product-formula circuit (one substep per recorded update).

For the horizontal time variable, use:

> scaled iteration coordinate \(\tau=\mathrm{step}/n\), not a common physical time shared across the four families.

Do not use:

- “converged XXZ dynamics” for the existing public rows;
- “four quantum-chaos families” as an umbrella label for every condition;
- localization or Hamiltonian-phase conclusions from the one-substep trajectories.

## Release status

PR-001 closes the XXZ physical-control blocker **only under this narrowed circuit interpretation**.

The repository remains unreleasable until the other peer-review blockers are closed:

- end-to-end public-figure provenance;
- exact Hartley/Rényi-0 handling;
- frozen release environment and green hosted CI.
