# Checkpoint PR-001 — XXZ Product-Formula Convergence

## Status

**Complete.** No GitHub files were modified during this checkpoint.

## Purpose

The peer-review audit found that the public random-field XXZ trajectories used one symmetric product-formula substep per record interval without a convergence check. This checkpoint isolates that assumption, measures its effect, and freezes the scientifically defensible interpretation.

## Computation completed

- Sizes: \(n=10,12,14\).
- Runs: `XXZ_1` through `XXZ_4`.
- Product-formula substeps: \(1,2,4,8,16,32\).
- Recorded trajectories: 72.
- Recorded half-chain observations: 3,528.
- Seeds, parameters, record interval, and sampling grid held fixed.
- Six normalized spectrum coordinates compared.

## Primary results

1. One substep is not convergence controlled. The largest one-versus-32-substep discrepancy is approximately 0.5755.
2. The refinement error follows second-order scaling for every tested coordinate.
3. Sixteen versus 32 substeps changes any tested normalized coordinate by at most 0.001662, with worst RMS error 0.001057.
4. The global boundary-normalized common-mode fraction is stable:
   - one substep: 0.902628;
   - 16 substeps: 0.902071;
   - 32 substeps: 0.902061.
5. The central metric-atlas conclusion survives, while the one-substep XXZ trajectory itself can change substantially.

## Frozen decision

The existing public rows should be interpreted as a fixed one-substep product-formula circuit family, not as converged continuous-time random-field XXZ Hamiltonian dynamics.

This closes PR-001 under a deliberate scope narrowing. It does not justify Hamiltonian-phase or localization claims from the existing rows.

## Next blocker

PR-002: repair the public-figure pipeline so freshly recomputed analysis tables are the actual inputs to the public figures, or are verified byte-for-byte against the frozen figure-input archive.
